import d3rlpy

from d3rlpy.optimizers import (
    AdamWFactory,
    GPTAdamWFactory,
    WarmupSchedulerFactory,
    RMSpropFactory                          
)
from d3rlpy.models import VectorEncoderFactory
from d3rlpy.preprocessing import StandardObservationScaler, MultiplyRewardScaler

from d3rlpy.algos.transformer.action_samplers import (
    IdentityQActionSampler,
    GradientAscentQActionSampler, 
)


q_action_samplers = dict(
    i=IdentityQActionSampler,
    a=GradientAscentQActionSampler,
)

q_action_sampler = q_action_samplers["i"]
eval_interval = 10


ENV_CONFIG = {

    "antmaze_dt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-2),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=1.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        ) 
    },
    "antmaze_ddt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-2),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=1.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        ) 
    },
    "maze2d_dt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(5e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=1.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        ) 
    },
    "maze2d_ddt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(5e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=1.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        ) 
    },
    "hopper_dt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=7200, # 3600.0,  # specify target environment return
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        ) 
    },
    "hopper_ddt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=7200,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        ) 
    },
    "halfcheetah_dt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=12000.0,  # specify target environment return
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        )
    },

    "halfcheetah_ddt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=12000.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        )
    },
    "walker2d_dt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=5000.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        )
    },

    "walker2d_ddt" : {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-3),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=5000.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        )
    },
    "reacher2d_dt": {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-1),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=76.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        )
    },

    "reacher2d_ddt": {
        "algo": dict(
            num_layers=3,
            num_heads=1,
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128],
                exclude_last_activation=True,
            ),
            activation_type="relu",
            batch_size=128,
            optim_factory=AdamWFactory(
                clip_grad_norm=0.25, 
                weight_decay=1e-4,
                lr_scheduler_factory=WarmupSchedulerFactory(warmup_steps=10000),
            ),
            learning_rate=1e-4,
            attn_dropout=0.1,
            resid_dropout=0.1,
            context_size=20,
            max_timestep=1000,
            reward_scaler=MultiplyRewardScaler(1e-1),
            observation_scaler=StandardObservationScaler(),
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=76.0,
            n_evals=100,
            eval_interval=eval_interval,
            show_progress=False,
        )
    },

    "2048_dt": {
        "algo": dict(
            gamma=1,
            batch_size=64,
            context_size=20,
            learning_rate=1e-4,
            activation_type="relu",
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128, 128],
                exclude_last_activation=True,
            ),
            num_heads=1,
            num_layers=3,
            attn_dropout=0.1,
            embed_dropout=0.1,
            optim_factory=GPTAdamWFactory(
                weight_decay=1e-4,
                clip_grad_norm=0.25,
            ),
            warmup_tokens=10000*100,
            max_timestep=500,
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=1.0,
            n_evals=100,
            eval_action_sampler=d3rlpy.algos.GreedyTransformerActionSampler(),
            show_progress=False,
        )
    },

    "2048_ddt": {
        "algo": dict(
            gamma=1,
            batch_size=64,
            context_size=20,
            learning_rate=1e-4,
            activation_type="relu",
            encoder_factory=VectorEncoderFactory(
                hidden_units=[128, 128],
                exclude_last_activation=True,
            ),
            num_heads=1,
            num_layers=3,
            attn_dropout=0.1,
            embed_dropout=0.1,
            optim_factory=GPTAdamWFactory(
                weight_decay=1e-4,
                clip_grad_norm=0.25,
            ),
            warmup_tokens=10000*100,
            max_timestep=500,
            position_encoding_type=d3rlpy.PositionEncodingType.SIMPLE,
        ),
        "fit": dict(
            n_steps=1000000,
            n_steps_per_epoch=1000,
            save_interval=1,
            eval_target_return=1.0,
            n_evals=100,
            eval_action_sampler=d3rlpy.algos.GreedyTransformerActionSampler(),
            show_progress=False,
        )
    },
}