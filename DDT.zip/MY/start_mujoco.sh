#!/bin/bash


experiment_id=3


envs=("hopper" "walker2d" "halfcheetah")
versions=("medium" "medium-expert" "medium-replay" "random")
confs=("_ddt")
gpus=(0 1 6 7 0 1 2 3 4 5 6 7)
seeds=(0 6 42 114514 1919810)
gpu_num=${#gpus[@]}

declare -a pids=()

i=0

for conf in ${confs[@]};
do
    for env in ${envs[@]};
    do
        conf_name=${env}${conf}
        for version in ${versions[@]};
        do
            full_env_name=${env}-${version}-v2
            log_file_name=./print_logs/pcdt/${experiment_id}${conf}_${env}_${version}.txt
            python ./train.py --env ${full_env_name} --device cuda:${gpus[$i]} --conf ${conf_name} --seed ${seeds[$experiment_id]} >> ${log_file_name} 2>&1 &
            pid=$!
            pids+=($pid)
            i=$(( (i+1) ))

            echo "Starting Experiment at time $(date), pid=${pid}"
        done
    done
done

cleanup() {
    echo -e "\nScript interrupted. Terminating all background experiments..."
    for pid in ${pids[@]};
    do
        if ps -p $pid > /dev/null 2>&1; then
            kill -9 $pid > /dev/null 2>&1
            echo "Terminated experiment with pid=${pid}."
        else
            echo "Experiment with pid=${pid} already completed."
        fi
    done
    exit 1
}

trap cleanup SIGINT SIGTERM EXIT

for pid in ${pids[@]};
do
    wait $pid
    exit_code=$?
    if [ $exit_code -ne 0 ]; then
        echo "Experiment with pid=${pid} failed with exit code ${exit_code}."
    else
        echo "Experiment with pid=${pid} completed successfully."
    fi
done

echo "All experiments done!"