#!/bin/bash


experiment_id=0


envs=("hopper")
versions=("medium")
confs=("_ddt")

tag="a"

gpus=(0 1 2 4 0 1 2 4 0 1 2 4 0 1 2 6 5 5 6 6)
seeds=(0 1 2 3 4)

iters=(16 32 64 128)

gpu_num=${#gpus[@]}

declare -a pids=()

i=0

for conf in ${confs[@]};
do
    for env in ${envs[@]};
    do
        conf_name=${env}${conf}
        for version in ${versions[@]};
        do
            for experiment_id in "${!seeds[@]}";
            do
                for iter in ${iters[@]};
                do
                    full_env_name=${env}-${version}-v2

                    log_file_name=./${tag}_${env}_print_logs/importance_sampling_s${experiment_id}_i${iter}_${experiment_id}${conf}_${env}_${version}.txt

                    python ./train.py --env ${full_env_name} --device cuda:${gpus[$i]} --conf ${conf_name} --seed ${seeds[$experiment_id]} --logpath ./${tag}_${env}_d3rlpy_logs --tag ${tag} --q_action_sampler a --default_iterations ${iter} > ${log_file_name} 2>&1 &
                    pid=$!
                    pids+=($pid)
                    i=$(( i+1 ))
                    # i=$(( (i+1) % gpu_num ))

                    echo "Starting Experiment at time $(date), pid=${pid}"
                done
            done
        done
    done
done

# 定义清理函数
cleanup() {
    echo -e "\nScript interrupted. Terminating all background experiments..."
    for pid in ${pids[@]};
    do
        if ps -p $pid > /dev/null 2>&1; then
            kill -9 $pid > /dev/null 2>&1
            echo "Terminated experiment with pid=${pid}."
        else
            echo "Experiment with pid=${pid} already completed."
        fi
    done
    exit 1
}

trap cleanup SIGINT SIGTERM EXIT

# 等待所有后台进程完成
for pid in ${pids[@]};
do
    wait $pid
    exit_code=$?
    if [ $exit_code -ne 0 ]; then
        echo "Experiment with pid=${pid} failed with exit code ${exit_code}."
    else
        echo "Experiment with pid=${pid} completed successfully."
    fi
done

echo "All experiments done!"