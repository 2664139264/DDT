from argparse import ArgumentParser, SUPPRESS

import d3rlpy
from d3rlpy.logging import FileAdapterFactory
from d3rlpy.algos import (
    DecisionTransformerConfig as DTConfig,
    AQDecisionTransformerConfig as AQCDTConfig,
    DecoupledDecisionTransformerConfig as DDTConfig,
)
from d3rlpy.algos.transformer.action_samplers import IdentityQActionSampler


from env_configs import ENV_CONFIG, q_action_samplers

if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--env", type=str, default="hopper-medium-v2")
    parser.add_argument("--device", type=str, default="cuda:7")
    parser.add_argument("--conf", type=str, default="hopper_ddt")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--logpath", type=str, default="d3rlpy_logs")
    parser.add_argument("--tag", type=str, default="")
    parser.add_argument("--q_action_sampler", type=str, default="i")
    parser.add_argument("--default_iterations", type=int, default=0)
    parser.add_argument("--eval_interval", type=int, default=1)
    parser.add_argument("--target", type=float, default=SUPPRESS)

    args = parser.parse_args()
    
    d3rlpy.seed(args.seed)

    dataset, env = d3rlpy.datasets.get_d4rl(args.env)
    conf_name = args.conf
    
    eval_callback = None
    config = ENV_CONFIG[conf_name]
    
    config["fit"]["eval_interval"] = args.eval_interval

    if args.conf.endswith("_aqdt"):
        config_type = AQCDTConfig
        if args.q_action_sampler == "i":
            config["algo"]["q_action_sampler"] = q_action_samplers[args.q_action_sampler]()
        else:
            config["algo"]["q_action_sampler"] = q_action_samplers[args.q_action_sampler](
                iterations = args.default_iterations
            )

            def cbk(self, epoch, total_step):
                if total_step % config["fit"]["n_steps_per_epoch"] != 0:
                    return
                if epoch % 10 == 0:
                    self._impl._q_action_sampler = config["algo"]["q_action_sampler"]
                    print(f"Switched to sampler {q_action_samplers[args.q_action_sampler].__name__} for evaluation.")
                else:
                    self._impl._q_action_sampler = IdentityQActionSampler()
                    print(f"Switched to sampler {IdentityQActionSampler.__name__} for evaluation.")

            eval_callback = cbk

    elif args.conf.endswith("_ddt"):
        config_type = DDTConfig
    else:
        config_type = DTConfig
    
    dt = config_type(**config["algo"]).create(device=args.device)

    if hasattr(args, 'target'):
        config["fit"]["eval_target_return"] = args.target

    dt.fit(
        dataset,
        eval_env=env,
        experiment_name=f"{args.tag}{args.env}_{conf_name.split('_')[1]}_seed{args.seed}_iter{args.default_iterations}",
        **config["fit"],
        logger_adapter=FileAdapterFactory(args.logpath),
        callback=eval_callback,
    )

    