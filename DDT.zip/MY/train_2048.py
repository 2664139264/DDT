from argparse import ArgumentParser
from d3rlpy.algos import (
    AQDiscreteDecisionTransformerConfig as AQDDTConfig,
    DiscreteDecisionTransformerConfig as DDTConfig, 
    QDiscreteDecisionTransformerConfig as QDDTConfig,
    DecoupledDiscreteDecisionTransformerConfig as DDTConfig,
    DQNConfig,
    DoubleDQNConfig,
    IQLConfig,
)
from d3rlpy.metrics import EnvironmentEvaluator
import d3rlpy

from env_configs import ENV_CONFIG

if __name__ == "__main__":
    
    parser = ArgumentParser()

    parser.add_argument("--dataset", type=str, default="./d3rlpy_data/2048.h5")
    parser.add_argument("--device", type=str, default="cuda:3")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--conf", type=str, default="2048_aqdt")
    parser.add_argument("--temperature", type=float, default=0.1)

    args = parser.parse_args()
    
    dataset, env = d3rlpy.datasets.get_2048(data_path=args.dataset)

    d3rlpy.seed(args.seed)

    conf_name = args.conf

    if conf_name == "2048_aqdt":
        dt = AQDDTConfig(**ENV_CONFIG[conf_name]["algo"]).create(device=args.device)
        ENV_CONFIG[conf_name]["fit"]["eval_env"] = env
        
    elif conf_name == "2048_dt":
        dt = DDTConfig(**ENV_CONFIG[conf_name]["algo"]).create(device=args.device)
        ENV_CONFIG[conf_name]["fit"]["eval_env"] = env
    elif conf_name == "2048_qdt":

        dt = QDDTConfig(**ENV_CONFIG[conf_name]["algo"]).create(device=args.device)
        ENV_CONFIG[conf_name]["fit"]["eval_env"] = env
        
        def cbk(self, epoch, total_step):
            if epoch == 10 and not self._impl._start_dt:
                self._impl._start_dt = True
                print(">>>>  Switched to DT  <<<<")
        
        ENV_CONFIG[conf_name]["fit"]["callback"] = cbk
        
    elif conf_name == "2048_dqn":
        dt = DQNConfig(**ENV_CONFIG[conf_name]["algo"]).create(device=args.device)
        ENV_CONFIG[conf_name]["fit"]["evaluators"] = {"env": EnvironmentEvaluator(env=env, n_trials=100)}
    elif conf_name == "2048_ddqn":
        dt = DoubleDQNConfig(**ENV_CONFIG[conf_name]["algo"]).create(device=args.device)
        ENV_CONFIG[conf_name]["fit"]["evaluators"] = {"env": EnvironmentEvaluator(env=env, n_trials=100)}
    elif conf_name == "2048_iql":
        dt = IQLConfig(**ENV_CONFIG[conf_name]["algo"]).create(device=args.device)
        ENV_CONFIG[conf_name]["fit"]["evaluators"] = {"env": EnvironmentEvaluator(env=env, n_trials=100)}
    elif conf_name == "2048_ddt":
        dt = DDTConfig(**ENV_CONFIG[conf_name]["algo"]).create(device=args.device)
        ENV_CONFIG[conf_name]["fit"]["eval_env"] = env

        
    print(conf_name, dataset, env)

    dt.fit(
        dataset,
        experiment_name=f"{conf_name}",
        **ENV_CONFIG[conf_name]["fit"],
    )
    