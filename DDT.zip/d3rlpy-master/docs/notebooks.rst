Jupyter Notebooks
=================

* `CartPole <https://github.com/takuseno/d3rlpy/blob/master/tutorials/cartpole.ipynb>`_
* `CartPole (online) <https://github.com/takuseno/d3rlpy/blob/master/tutorials/online.ipynb>`_
* `Discrete Control with Atari <https://github.com/takuseno/d3rlpy/blob/master/tutorials/atari.ipynb>`_
* `TPU Example <https://github.com/takuseno/d3rlpy/blob/master/tutorials/tpu.ipynb>`_
