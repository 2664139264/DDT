Paper Reproductions
-------------------

For the experiment code, please take a look at
`reproductions <https://github.com/takuseno/d3rlpy/tree/master/reproductions>`_ directory.

All the experimental results are available in `d3rlpy-benchmarks <https://github.com/takuseno/d3rlpy-benchmarks>`_ repository.
