from typing import Protocol, Union

import numpy as np

from ...types import NDArray

__all__ = [
    "TransformerActionSampler",
    "IdentityTransformerActionSampler",
    "SoftmaxTransformerActionSampler",
    "GreedyTransformerActionSampler",
]


class TransformerActionSampler(Protocol):
    r"""Interface of TransformerActionSampler."""

    def __call__(self, transformer_output: NDArray) -> Union[NDArray, int]:
        r"""Returns sampled action from Transformer output.

        Args:
            transformer_output: Output of Transformer algorithms.

        Returns:
            Sampled action.
        """
        raise NotImplementedError


class IdentityTransformerActionSampler(TransformerActionSampler):
    r"""Identity action-sampler.

    This class implements identity function to process Transformer output.
    Sampled action is the exactly same as ``transformer_output``.
    """

    def __call__(self, transformer_output: NDArray) -> Union[NDArray, int]:
        return transformer_output


class SoftmaxTransformerActionSampler(TransformerActionSampler):
    r"""Softmax action-sampler.

    This class implements softmax function to sample action from discrete
    probability distribution.

    Args:
        temperature (int): Softmax temperature.
    """

    _temperature: float

    def __init__(self, temperature: float = 1.0):
        self._temperature = temperature

    def __call__(self, transformer_output: NDArray) -> Union[NDArray, int]:
        assert transformer_output.ndim == 1
        logits = transformer_output / self._temperature
        x = np.exp(logits - np.max(logits))
        probs = x / np.sum(x)
        action = np.random.choice(probs.shape[0], p=probs)
        return int(action)


class GreedyTransformerActionSampler(TransformerActionSampler):
    r"""Greedy action-sampler.

    This class implements greedy function to determine action from discrte
    probability distribution.
    """

    def __call__(self, transformer_output: NDArray) -> Union[NDArray, int]:
        assert transformer_output.ndim == 1
        return int(np.argmax(transformer_output))


#######################################################################


from typing import Callable
from dataclasses import dataclass

import torch
from torch import nn


@dataclass()
class QActionSampler(Protocol):
    r"""Interface of QActionSampler."""

    def __call__(
        self,
        q_func: Callable[[NDArray, NDArray], NDArray],
        h_q: NDArray,
        action: NDArray,
    ) -> NDArray:

        raise NotImplementedError


@dataclass()
class IdentityQActionSampler(QActionSampler):
    r"""Identity action-sampler for Q-function.

    This class implements identity function to process action.
    Sampled action is the exactly same as ``action``.
    """

    def __call__(
        self,
        q_func: Callable[[NDArray, NDArray], NDArray],
        h_q: NDArray,
        action: NDArray,
    ) -> NDArray:
        return action


@dataclass()
class GradientAscentQActionSampler(QActionSampler):
    r"""Gradient ascent action-sampler for Q-function.

    This class implements gradient ascent to find action that maximizes Q-value.

    Args:
        n_iterations (int): Number of gradient ascent iterations.
    """

    _iterations: int

    def __init__(
        self,
        iterations: int = 16
    ):
        self._iterations = iterations

    def __call__(
        self,
        q_func: Callable[[NDArray, NDArray], NDArray],
        h_q: NDArray,
        action: NDArray,
    ) -> NDArray:

        q_out = q_func(h_q, action)

        with torch.enable_grad():
            best_a = action
            max_q = q_out.item()
            a_param = nn.Parameter(action.clone(), requires_grad=True)
            optim = torch.optim.Adam([a_param])

            for _ in range(self._iterations):

                pred_q = q_func(h_q, a_param)

                if pred_q.item() > max_q:
                    max_q = pred_q.item()
                    best_a = a_param.detach().clone()

                optim.zero_grad()
                (-pred_q).backward()
                optim.step()

        return best_a

@dataclass()
class MaximizeQActionSampler(QActionSampler):

    _iterations: int

    def __init__(
        self,
        iterations: int = 16
    ):
        self._iterations = iterations

    def __call__(
        self,
        q_func: Callable[[NDArray, NDArray], NDArray],
        h_q: NDArray,
        action: NDArray,
    ) -> NDArray:

        # 完全随机选择一个动作，抛弃原有动作
        action = 2 * torch.rand_like(action) - 1

        q_out = q_func(h_q, action)

        with torch.enable_grad():
            best_a = action
            max_q = q_out.item()
            a_param = nn.Parameter(action.clone(), requires_grad=True)
            optim = torch.optim.Adam([a_param])

            for _ in range(self._iterations):

                pred_q = q_func(h_q, a_param)

                if pred_q.item() > max_q:
                    max_q = pred_q.item()
                    best_a = a_param.detach().clone()

                optim.zero_grad()
                (-pred_q).backward()
                optim.step()

        return best_a


@dataclass()
class RandomMaxQActionSampler(QActionSampler):
    _n_samples: int
    
    def __init__(
        self,
        n_samples: int = 512
    ):
        self._n_samples = n_samples
    
    def __call__(
        self,
        q_func: Callable[[NDArray, NDArray], NDArray],
        h_q: NDArray,
        action: NDArray,
    ) -> NDArray:
    
        actions = 2 * torch.rand_like(action.broadcast_to((self._n_samples, *action.shape))) - 1  # [n_samples, action_dim]
        h_qs = h_q.broadcast_to((self._n_samples, *h_q.shape))  # [n_samples, h_q_dim]
        q_values = q_func(h_qs, actions).squeeze()  # [n_samples]
        max_idx = torch.argmax(q_values).item()
        best_a = actions[max_idx]
        return best_a


@dataclass()
class QActionScorer(Protocol):
    r"""Interface of QActionSampler."""

    def __call__(
        self,
        logits: NDArray,
        h_q: NDArray,
        q_values: NDArray,
    ) -> NDArray:

        raise NotImplementedError

@dataclass()
class LogitsQActionScorer(QActionScorer):

    def __call__(
        self,
        logits: NDArray,
        h_q: NDArray,
        q_values: NDArray,
    ) -> NDArray:

        assert logits.ndim == 1
        return logits
    

@dataclass()
class DiscreteQActionScorer(QActionScorer):

    def __call__(
        self,
        logits: NDArray,
        h_q: NDArray,
        q_values: NDArray,
    ):
        assert q_values.ndim == 1
        return q_values


@dataclass()
class SoftmaxQActionScorer(QActionScorer):

    _temperature: float
    _epsilon: float

    def __init__(self, temperature: float = 1.0, epsilon: float = 1e-4):
        self._temperature = temperature
        self._epsilon = epsilon
    
    def __call__(
        self,
        logits: NDArray,
        h_q: NDArray,
        q_values: NDArray,
    ):
        assert q_values.ndim == 1
        return (
            logits + self._temperature * q_values * (
                (logits.abs().mean() + self._epsilon) / (q_values.abs().mean() + self._epsilon)
            )
        )


__all__.append(QActionSampler.__name__)
__all__.append(IdentityQActionSampler.__name__)
__all__.append(GradientAscentQActionSampler.__name__)
__all__.append(MaximizeQActionSampler.__name__)
__all__.append(RandomMaxQActionSampler.__name__)
__all__.append(QActionScorer.__name__)
__all__.append(LogitsQActionScorer.__name__)
__all__.append(DiscreteQActionScorer.__name__)
__all__.append(SoftmaxQActionScorer.__name__)
