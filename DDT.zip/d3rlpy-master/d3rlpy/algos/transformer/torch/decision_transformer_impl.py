import dataclasses
import math
from typing import Callable

import torch
import torch.nn.functional as F

from ....models.torch import (
    ContinuousDecisionTransformer,
    DiscreteDecisionTransformer,
)
from ....optimizers import OptimizerWrapper
from ....torch_utility import (
    CudaGraphWrapper,
    Modules,
    TorchTrajectoryMiniBatch,
)
from ....types import Shape
from ..base import TransformerAlgoImplBase
from ..inputs import TorchTransformerInput

__all__ = [
    "DecisionTransformerImpl",
    "DecisionTransformerModules",
    "DiscreteDecisionTransformerModules",
    "DiscreteDecisionTransformerImpl",
]


@dataclasses.dataclass(frozen=True)
class DecisionTransformerModules(Modules):
    transformer: ContinuousDecisionTransformer
    optim: OptimizerWrapper


class DecisionTransformerImpl(TransformerAlgoImplBase):
    _modules: DecisionTransformerModules
    _compute_grad: Callable[[TorchTrajectoryMiniBatch], dict[str, torch.Tensor]]

    def __init__(
        self,
        observation_shape: Shape,
        action_size: int,
        modules: Modules,
        compiled: bool,
        device: str,
    ):
        super().__init__(observation_shape, action_size, modules, device)
        self._compute_grad = (
            CudaGraphWrapper(self.compute_grad)
            if compiled
            else self.compute_grad
        )

    def inner_predict(self, inpt: TorchTransformerInput) -> torch.Tensor:
        # (1, T, A)
        action = self._modules.transformer(
            inpt.observations,
            inpt.actions,
            inpt.returns_to_go,
            inpt.timesteps,
            1 - inpt.masks,
        )
        # (1, T, A) -> (A,)
        return action[0][-1]

    def compute_grad(
        self, batch: TorchTrajectoryMiniBatch
    ) -> dict[str, torch.Tensor]:
        self._modules.optim.zero_grad()
        loss = self.compute_loss(batch)
        loss.backward()
        return {"loss": loss}

    def inner_update(
        self, batch: TorchTrajectoryMiniBatch, grad_step: int
    ) -> dict[str, float]:
        loss = self._compute_grad(batch)
        self._modules.optim.step()
        return {"loss": float(loss["loss"].cpu().detach().numpy())}

    def compute_loss(self, batch: TorchTrajectoryMiniBatch) -> torch.Tensor:
        action = self._modules.transformer(
            batch.observations,
            batch.actions,
            batch.returns_to_go,
            batch.timesteps,
            1 - batch.masks,
        )
        # (B, T, A) -> (B, T)
        loss = ((action - batch.actions) ** 2).sum(dim=-1)
        return (loss.reshape(-1) * batch.masks.reshape(-1)).mean()


@dataclasses.dataclass(frozen=True)
class DiscreteDecisionTransformerModules(Modules):
    transformer: DiscreteDecisionTransformer
    optim: OptimizerWrapper


class DiscreteDecisionTransformerImpl(TransformerAlgoImplBase):
    _modules: DiscreteDecisionTransformerModules
    _warmup_tokens: int
    _final_tokens: int
    _initial_learning_rate: float
    _tokens: int
    _compute_grad: Callable[[TorchTrajectoryMiniBatch], dict[str, torch.Tensor]]

    def __init__(
        self,
        observation_shape: Shape,
        action_size: int,
        modules: DiscreteDecisionTransformerModules,
        warmup_tokens: int,
        final_tokens: int,
        initial_learning_rate: float,
        compiled: bool,
        device: str,
    ):
        super().__init__(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            device=device,
        )
        self._warmup_tokens = warmup_tokens
        self._final_tokens = final_tokens
        self._initial_learning_rate = initial_learning_rate
        self._compute_grad = (
            CudaGraphWrapper(self.compute_grad)
            if compiled
            else self.compute_grad
        )
        # TODO: Include stateful information in checkpoint.
        self._tokens = 0

    def inner_predict(self, inpt: TorchTransformerInput) -> torch.Tensor:
        # (1, T, A)
        _, logits = self._modules.transformer(
            inpt.observations,
            inpt.actions,
            inpt.returns_to_go,
            inpt.timesteps,
            1 - inpt.masks,
        )
        # (1, T, A) -> (A,)
        return logits[0][-1]

    def compute_grad(
        self, batch: TorchTrajectoryMiniBatch
    ) -> dict[str, torch.Tensor]:
        self._modules.optim.zero_grad()
        loss = self.compute_loss(batch)
        loss.backward()
        return {"loss": loss}

    def inner_update(
        self, batch: TorchTrajectoryMiniBatch, grad_step: int
    ) -> dict[str, float]:
        loss = self._compute_grad(batch)
        self._modules.optim.step()

        # schedule learning rate
        self._tokens += int(batch.masks.sum().cpu().detach().numpy())
        if self._tokens < self._warmup_tokens:
            # linear warmup
            lr_mult = self._tokens / max(1, self._warmup_tokens)
        else:
            # cosine learning rate decay
            progress = (self._tokens - self._warmup_tokens) / max(
                1, self._final_tokens - self._warmup_tokens
            )
            lr_mult = max(0.1, (1.0 + math.cos(math.pi * progress)) / 2.0)
        new_learning_rate = lr_mult * self._initial_learning_rate
        for param_group in self._modules.optim.optim.param_groups:
            param_group["lr"] = new_learning_rate

        return {
            "loss": float(loss["loss"].cpu().detach().numpy()),
            "learning_rate": new_learning_rate,
        }

    def compute_loss(self, batch: TorchTrajectoryMiniBatch) -> torch.Tensor:
        _, logits = self._modules.transformer(
            batch.observations,
            batch.actions,
            batch.returns_to_go,
            batch.timesteps,
            1 - batch.masks,
        )
        loss = F.cross_entropy(
            logits.view(-1, self._action_size),
            batch.actions.view(-1).long(),
            reduction="none",
        )
        return loss.mean()


#######################################################################


from ....models.torch import (
    QDiscreteDecisionTransformer,
    AQDiscreteDecisionTransformer,
    AQContinuousDecisionTransformer,
    DecoupledDiscreteDecisionTransformer,
    DecoupledContinuousDecisionTransformer,
)
from ....torch_utility import TorchTrajectoryMiniBatch
from ..action_samplers import QActionSampler, QActionScorer


@dataclasses.dataclass(frozen=True)
class QDiscreteDecisionTransformerModules(Modules):
    transformer: QDiscreteDecisionTransformer
    optim: OptimizerWrapper


class QDiscreteDecisionTransformerImpl(TransformerAlgoImplBase):
    _modules: QDiscreteDecisionTransformerModules
    _warmup_tokens: int
    _final_tokens: int
    _initial_learning_rate: float
    _tokens: int
    _compute_grad: Callable[[TorchTrajectoryMiniBatch], dict[str, torch.Tensor]]
    
    _start_dt: bool

    def __init__(
        self,
        observation_shape: Shape,
        action_size: int,
        modules: QDiscreteDecisionTransformerModules,
        warmup_tokens: int,
        final_tokens: int,
        initial_learning_rate: float,
        compiled: bool,
        device: str,
    ):
        super().__init__(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            device=device,
        )
        self._warmup_tokens = warmup_tokens
        self._final_tokens = final_tokens
        self._initial_learning_rate = initial_learning_rate
        self._compute_grad = (
            CudaGraphWrapper(self.compute_grad)
            if compiled
            else self.compute_grad
        )
        # TODO: Include stateful information in checkpoint.
        self._tokens = 0
        self._start_dt = False

    def inner_predict(self, inpt: TorchTransformerInput) -> torch.Tensor:
        # (1, T, A)
        h, q_values = self._modules.transformer(
            inpt.observations,
            inpt.actions,
            inpt.returns_to_go,
            inpt.timesteps,
            1 - inpt.masks,
        )
        return q_values[0][-1]

    def compute_grad(
        self, batch: TorchTrajectoryMiniBatch
    ) -> dict[str, torch.Tensor]:
        self._modules.optim.zero_grad()
        loss = self.compute_loss(batch)
        loss.backward()
        return {"loss": loss}
    
    def inner_update(
        self, batch: TorchTrajectoryMiniBatch, grad_step: int
    ) -> dict[str, float]:
        loss = self._compute_grad(batch)
        self._modules.optim.step()

        # schedule learning rate
        self._tokens += int(batch.masks.sum().cpu().detach().numpy())
        if self._tokens < self._warmup_tokens:
            # linear warmup
            lr_mult = self._tokens / max(1, self._warmup_tokens)
        else:
            # cosine learning rate decay
            progress = (self._tokens - self._warmup_tokens) / max(
                1, self._final_tokens - self._warmup_tokens
            )
            lr_mult = max(0.1, (1.0 + math.cos(math.pi * progress)) / 2.0)
        new_learning_rate = lr_mult * self._initial_learning_rate
        for param_group in self._modules.optim.optim.param_groups:
            param_group["lr"] = new_learning_rate

        return {
            "loss": float(loss["loss"].cpu().detach().numpy()),
            "learning_rate": new_learning_rate,
        }

    def compute_loss(self, batch: TorchTrajectoryMiniBatch) -> torch.Tensor:
        h, q_values = self._modules.transformer(
            batch.observations,
            batch.actions,
            batch.returns_to_go,
            batch.timesteps,
            1 - batch.masks,
        )
        # Find the Q values corresponding to the taken actions
        # Take RTG as the target Q values
        
        # 直接拟合 Q^\pi
        if not self._start_dt:
            loss = F.mse_loss(
                q_values.view(-1, self._action_size).gather(1, batch.actions.view(-1,1).long()).squeeze(),
                batch.returns_to_go.view(-1),
                reduction="none",
            ).mean()
        else:
            # 使用动态规划拟合 Q^\ast
            
            # (B, T, A) -> (B*T, A)

            cur_qs = q_values[:, :-1, :].reshape(-1, self._action_size)
            nxt_qs = q_values[:, 1:,  :].reshape(-1, self._action_size)

            cur_as = batch.actions[:, :-1, :].reshape(-1, 1).long()
            cur_rs = batch.rewards[:, :-1, :].flatten()

            # (B*T, A) -> (B*T, 1) -> (B*T)
            cur_q_values = cur_qs.gather(1, cur_as).squeeze()
            
            # TODO: softmax?
            nxt_q_values = nxt_qs.max(dim=-1).values
            
            # TODO: add GAMMA
            target_values = cur_rs + nxt_q_values
            
            cur_loss = F.mse_loss(
                cur_q_values,
                target_values,
                reduction="mean"
            )

            last_qs = (q_values[:, -1, :] * batch.terminals[:, -1, :].expand(q_values.shape[0], self._action_size)).flatten()
            last_target = (batch.rewards[:, -1, :] * batch.terminals[:, -1, :]).expand(q_values.shape[0], self._action_size).flatten()
            
            final_loss = F.mse_loss(
                last_qs,
                last_target,
                reduction="mean"
            )
            loss = cur_loss + final_loss

        return loss


@dataclasses.dataclass(frozen=True)
class AQDiscreteDecisionTransformerModules(Modules):
    transformer: AQDiscreteDecisionTransformer
    optim: OptimizerWrapper


class AQDiscreteDecisionTransformerImpl(TransformerAlgoImplBase):
    _modules: AQDiscreteDecisionTransformerModules
    _warmup_tokens: int
    _final_tokens: int
    _initial_learning_rate: float
    _tokens: int
    _compute_grad: Callable[[TorchTrajectoryMiniBatch], dict[str, torch.Tensor]]
    _q_loss_ratio: float
    _q_action_scorer: QActionScorer
    _clip_min: float
    _clip_max: float
    _epsilon: float = 1e-4

    def __init__(
        self,
        observation_shape: Shape,
        action_size: int,
        modules: AQDiscreteDecisionTransformerModules,
        warmup_tokens: int,
        final_tokens: int,
        initial_learning_rate: float,
        compiled: bool,
        device: str,
        q_loss_ratio: float,
        q_action_scorer: QActionScorer,
        clip_min: float,
        clip_max: float,
    ):
        super().__init__(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            device=device,
        )
        self._warmup_tokens = warmup_tokens
        self._final_tokens = final_tokens
        self._initial_learning_rate = initial_learning_rate
        self._compute_grad = (
            CudaGraphWrapper(self.compute_grad)
            if compiled
            else self.compute_grad
        )
        # TODO: Include stateful information in checkpoint.
        self._tokens = 0
        self._q_loss_ratio=q_loss_ratio
        self._q_action_scorer=q_action_scorer
        self._clip_min, self._clip_max = clip_min, clip_max

    def inner_predict(self, inpt: TorchTransformerInput) -> torch.Tensor:
        # (1, T, A)
        logits, logits_pi, h_q, q_values = self._modules.transformer(
            inpt.observations,
            inpt.actions,
            inpt.returns_to_go,
            inpt.timesteps,
            1 - inpt.masks,
        )
        #TODO: mixing together protocol
        return self._q_action_scorer(
            logits[0][-1],
            h_q[0][-1],
            q_values[0][-1]
        )

    def compute_grad(
        self, batch: TorchTrajectoryMiniBatch
    ) -> dict[str, torch.Tensor]:
        self._modules.optim.zero_grad()
        loss_a, loss_pi, loss_q = self.compute_loss(batch)

        #TODO: weighting

        ######################################################################
        loss = (1 - self._q_loss_ratio) * (loss_a + loss_pi) + self._q_loss_ratio * loss_q
        loss.backward()
        return {"loss": loss, "loss_a": loss_a, "loss_pi": loss_pi, "loss_q": loss_q}

    def inner_update(
        self, batch: TorchTrajectoryMiniBatch, grad_step: int
    ) -> dict[str, float]:
        loss = self._compute_grad(batch)
        self._modules.optim.step()

        # schedule learning rate
        self._tokens += int(batch.masks.sum().cpu().detach().numpy())
        if self._tokens < self._warmup_tokens:
            # linear warmup
            lr_mult = self._tokens / max(1, self._warmup_tokens)
        else:
            # cosine learning rate decay
            progress = (self._tokens - self._warmup_tokens) / max(
                1, self._final_tokens - self._warmup_tokens
            )
            lr_mult = max(0.1, (1.0 + math.cos(math.pi * progress)) / 2.0)

        new_learning_rate = lr_mult * self._initial_learning_rate

        for param_group in self._modules.optim.optim.param_groups:
            param_group["lr"] = new_learning_rate

        return {
            "loss": float(loss["loss"].cpu().detach().numpy()),
            "loss_a": float(loss["loss_a"].cpu().detach().numpy()),
            "loss_pi": float(loss["loss_pi"].cpu().detach().numpy()),
            "loss_q": float(loss["loss_q"].cpu().detach().numpy()),
            "learning_rate": new_learning_rate,
        }

    def compute_loss(self, batch: TorchTrajectoryMiniBatch) -> torch.Tensor:
        logits, logits_pi, h_q, q_values = self._modules.transformer(
            batch.observations,
            batch.actions,
            batch.returns_to_go,
            batch.timesteps,
            1 - batch.masks,
        )

        loss_a = F.cross_entropy(
            logits.view(-1, self._action_size),
            batch.actions.view(-1).long(),
            reduction="none",
        )
        
        loss_pi = F.cross_entropy(
            logits_pi.view(-1, self._action_size),
            batch.actions.view(-1).long(),
            reduction="none",
        )

        # Find the Q values corresponding to the taken actions
        # Take RTG as the target Q values
        
        importance_ratio = torch.clamp(
            (
                (torch.softmax(logits_pi, dim=-1) + self._epsilon) / (torch.softmax(logits, dim=-1) + self._epsilon)
            ).view(-1, self._action_size).gather(1, batch.actions.view(-1, 1).long()).squeeze(),
            min = self._clip_min,
            max = self._clip_max
        )

        loss_q = F.mse_loss(
            q_values.view(-1, self._action_size).gather(1, batch.actions.view(-1, 1).long()).squeeze(),
            importance_ratio * batch.returns_to_go.view(-1),
            reduction="none",
        )

        
        # Critic guided loss
        # q_values_flatten =  q_values.view(-1, self._action_size).gather(1, batch.actions.view(-1, 1).long()).squeeze()
        # return_to_goes = batch.returns_to_go.view(-1)
        
        # tau = 0.8
        
        # ratio = torch.abs(tau - (return_to_goes <= q_values_flatten).float())
        
        # loss_q = ratio * F.mse_loss(
        #     q_values_flatten,
        #     return_to_goes,
        #     reduction="none",
        # )

        return loss_a.mean(), loss_pi.mean(), loss_q.mean()


@dataclasses.dataclass(frozen=True)
class AQDecisionTransformerModules(Modules):
    transformer: AQContinuousDecisionTransformer
    optim: OptimizerWrapper


class AQDecisionTransformerImpl(TransformerAlgoImplBase):
    _modules: AQDecisionTransformerModules
    _compute_grad: Callable[[TorchTrajectoryMiniBatch], dict[str, torch.Tensor]]
    _q_loss_ratio: float
    _q_action_sampler: QActionSampler

    def __init__(
        self,
        observation_shape: Shape,
        action_size: int,
        modules: Modules,
        compiled: bool,
        device: str,
        q_loss_ratio: float,
        q_action_sampler: QActionSampler,
    ):
        super().__init__(observation_shape, action_size, modules, device)
        self._compute_grad = (
            CudaGraphWrapper(self.compute_grad)
            if compiled
            else self.compute_grad
        )
        self._q_loss_ratio = q_loss_ratio
        self._q_action_sampler = q_action_sampler

    def inner_predict(self, inpt: TorchTransformerInput) -> torch.Tensor:
        # (1, T, A), (1, T, D), (1, T, 1)
        action, pi, h_q, q_out = self._modules.transformer(
            inpt.observations,
            inpt.actions,
            inpt.returns_to_go,
            inpt.timesteps,
            1 - inpt.masks,
        )
        # (1, T, A) -> (A,)
        action = action[0][-1]
        h_q = h_q[0][-1]

        return self._q_action_sampler(
            self._modules.transformer.call_q,
            h_q,
            action
        )

    def compute_grad(
        self, batch: TorchTrajectoryMiniBatch
    ) -> dict[str, torch.Tensor]:
        self._modules.optim.zero_grad()
        loss_a, loss_pi, loss_q = self.compute_loss(batch)

        loss = (1 - self._q_loss_ratio) * (loss_a + loss_pi) + self._q_loss_ratio * loss_q

        loss.backward()
        return {"loss_a": loss_a, "loss_pi": loss_pi, "loss_q": loss_q, "loss": loss}

    def inner_update(
        self, batch: TorchTrajectoryMiniBatch, grad_step: int
    ) -> dict[str, float]:
        loss = self._compute_grad(batch)
        self._modules.optim.step()
        return {
            "loss_a": float(loss["loss_a"].cpu().detach().numpy()),
            "loss_pi": float(loss["loss_pi"].cpu().detach().numpy()),
            "loss_q": float(loss["loss_q"].cpu().detach().numpy()),
            "loss": float(loss["loss"].cpu().detach().numpy()),
        }

    def compute_loss(self, batch: TorchTrajectoryMiniBatch) -> torch.Tensor:
        action, pi, h_q, q_out = self._modules.transformer(
            batch.observations,
            batch.actions,
            batch.returns_to_go,
            batch.timesteps,
            1 - batch.masks,
        )
        # (B, T, A) -> (B, T)
        loss_a = ((action - batch.actions) ** 2).sum(dim=-1)
        loss_pi = ((pi - batch.actions) ** 2).sum(dim=-1)
        # (B, T, 1) -> (B, T)

        # loss_q = (q_out.view(-1) - batch.returns_to_go.view(-1)) ** 2

        # Critic guided loss
        q_values_flatten = q_out.view(-1)
        return_to_goes = batch.returns_to_go.view(-1)        

        # tau = 0.7

        # ratio = torch.abs(tau - (return_to_goes <= q_values_flatten).float())

        ratio = 1
        # rand_rate = 0.2
        # ratio = (1 - rand_rate) + rand_rate * torch.rand_like(q_values_flatten)

        loss_q = ratio * F.mse_loss(
            q_values_flatten,
            return_to_goes,
            reduction="none",
        )

        return (
            (loss_a.reshape(-1) * batch.masks.reshape(-1)).mean(),
            (loss_pi.reshape(-1) * batch.masks.reshape(-1)).mean(),
            (loss_q.reshape(-1) * batch.masks.reshape(-1)).mean(),
        )


@dataclasses.dataclass(frozen=True)
class DecoupledDiscreteDecisionTransformerModules(Modules):
    transformer: DecoupledDiscreteDecisionTransformer
    optim: OptimizerWrapper


class DecoupledDiscreteDecisionTransformerImpl(TransformerAlgoImplBase):
    _modules: DecoupledDiscreteDecisionTransformerModules
    _warmup_tokens: int
    _final_tokens: int
    _initial_learning_rate: float
    _tokens: int
    _compute_grad: Callable[[TorchTrajectoryMiniBatch], dict[str, torch.Tensor]]

    def __init__(
        self,
        observation_shape: Shape,
        action_size: int,
        modules: DecoupledDiscreteDecisionTransformerModules,
        warmup_tokens: int,
        final_tokens: int,
        initial_learning_rate: float,
        compiled: bool,
        device: str,
    ):
        super().__init__(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            device=device,
        )
        self._warmup_tokens = warmup_tokens
        self._final_tokens = final_tokens
        self._initial_learning_rate = initial_learning_rate
        self._compute_grad = (
            CudaGraphWrapper(self.compute_grad)
            if compiled
            else self.compute_grad
        )
        # TODO: Include stateful information in checkpoint.
        self._tokens = 0

    def inner_predict(self, inpt: TorchTransformerInput) -> torch.Tensor:
        # (1, T, A)
        _, logits = self._modules.transformer(
            inpt.observations,
            inpt.actions,
            inpt.returns_to_go,
            inpt.timesteps,
            1 - inpt.masks,
        )
        # (1, T, A) -> (A,)
        return logits[0][-1]

    def compute_grad(
        self, batch: TorchTrajectoryMiniBatch
    ) -> dict[str, torch.Tensor]:
        self._modules.optim.zero_grad()
        loss = self.compute_loss(batch)
        loss.backward()
        return {"loss": loss}

    def inner_update(
        self, batch: TorchTrajectoryMiniBatch, grad_step: int
    ) -> dict[str, float]:
        loss = self._compute_grad(batch)
        self._modules.optim.step()

        # schedule learning rate
        self._tokens += int(batch.masks.sum().cpu().detach().numpy())
        if self._tokens < self._warmup_tokens:
            # linear warmup
            lr_mult = self._tokens / max(1, self._warmup_tokens)
        else:
            # cosine learning rate decay
            progress = (self._tokens - self._warmup_tokens) / max(
                1, self._final_tokens - self._warmup_tokens
            )
            lr_mult = max(0.1, (1.0 + math.cos(math.pi * progress)) / 2.0)
        new_learning_rate = lr_mult * self._initial_learning_rate
        for param_group in self._modules.optim.optim.param_groups:
            param_group["lr"] = new_learning_rate

        return {
            "loss": float(loss["loss"].cpu().detach().numpy()),
            "learning_rate": new_learning_rate,
        }

    def compute_loss(self, batch: TorchTrajectoryMiniBatch) -> torch.Tensor:
        _, logits = self._modules.transformer(
            batch.observations,
            batch.actions,
            batch.returns_to_go,
            batch.timesteps,
            1 - batch.masks,
        )
        loss = F.cross_entropy(
            logits.view(-1, self._action_size),
            batch.actions.view(-1).long(),
            reduction="none",
        )
        return loss.mean()


@dataclasses.dataclass(frozen=True)
class DecoupledDecisionTransformerModules(Modules):
    transformer: DecoupledContinuousDecisionTransformer
    optim: OptimizerWrapper


class DecoupledDecisionTransformerImpl(TransformerAlgoImplBase):
    _modules: DecoupledDecisionTransformerModules
    _compute_grad: Callable[[TorchTrajectoryMiniBatch], dict[str, torch.Tensor]]

    def __init__(
        self,
        observation_shape: Shape,
        action_size: int,
        modules: Modules,
        compiled: bool,
        device: str,
    ):
        super().__init__(observation_shape, action_size, modules, device)
        self._compute_grad = (
            CudaGraphWrapper(self.compute_grad)
            if compiled
            else self.compute_grad
        )

    def inner_predict(self, inpt: TorchTransformerInput) -> torch.Tensor:
        # (1, T, A)
        action = self._modules.transformer(
            inpt.observations,
            inpt.actions,
            inpt.returns_to_go,
            inpt.timesteps,
            1 - inpt.masks,
        )
        # (1, T, A) -> (A,)
        return action[0][-1]

    def compute_grad(
        self, batch: TorchTrajectoryMiniBatch
    ) -> dict[str, torch.Tensor]:
        self._modules.optim.zero_grad()
        loss = self.compute_loss(batch)
        loss.backward()
        return {"loss": loss}

    def inner_update(
        self, batch: TorchTrajectoryMiniBatch, grad_step: int
    ) -> dict[str, float]:
        loss = self._compute_grad(batch)
        self._modules.optim.step()
        return {"loss": float(loss["loss"].cpu().detach().numpy())}

    def compute_loss(self, batch: TorchTrajectoryMiniBatch) -> torch.Tensor:
        action = self._modules.transformer(
            batch.observations,
            batch.actions,
            batch.returns_to_go,
            batch.timesteps,
            1 - batch.masks,
        )
        # (B, T, A) -> (B, T)
        loss = ((action - batch.actions) ** 2).sum(dim=-1)
        return (loss.reshape(-1) * batch.masks.reshape(-1)).mean()


__all__.extend([
    QDiscreteDecisionTransformerImpl.__name__,
    QDiscreteDecisionTransformerModules.__name__,
    AQDiscreteDecisionTransformerImpl.__name__,
    AQDiscreteDecisionTransformerModules.__name__,
    AQDecisionTransformerImpl.__name__,
    AQDecisionTransformerModules.__name__,
    DecoupledDiscreteDecisionTransformerImpl.__name__,
    DecoupledDiscreteDecisionTransformerModules.__name__,
    DecoupledDecisionTransformerImpl.__name__,
    DecoupledDecisionTransformerModules.__name__,
])