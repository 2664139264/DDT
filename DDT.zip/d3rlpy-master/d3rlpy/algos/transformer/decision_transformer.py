import dataclasses

from ...base import DeviceArg, register_learnable
from ...constants import ActionSpace, PositionEncodingType
from ...models import EncoderFactory, make_encoder_field
from ...models.builders import (
    create_continuous_decision_transformer,
    create_discrete_decision_transformer,
)
from ...optimizers import OptimizerFactory, make_optimizer_field
from ...types import Shape
from .base import TransformerAlgoBase, TransformerConfig
from .torch.decision_transformer_impl import (
    DecisionTransformerImpl,
    DecisionTransformerModules,
    DiscreteDecisionTransformerImpl,
    DiscreteDecisionTransformerModules,
)

__all__ = [
    "DecisionTransformerConfig",
    "DecisionTransformer",
    "DiscreteDecisionTransformerConfig",
    "DiscreteDecisionTransformer",
]


@dataclasses.dataclass()
class DecisionTransformerConfig(TransformerConfig):
    """Config of Decision Transformer.

    Decision Transformer solves decision-making problems as a sequence modeling
    problem.

    References:
        * `Chen at el., Decision Transformer: Reinforcement Learning via
          Sequence Modeling. <https://arxiv.org/abs/2106.01345>`_

    Args:
        observation_scaler (d3rlpy.preprocessing.ObservationScaler):
            Observation preprocessor.
        action_scaler (d3rlpy.preprocessing.ActionScaler): Action preprocessor.
        reward_scaler (d3rlpy.preprocessing.RewardScaler): Reward preprocessor.
        context_size (int): Prior sequence length.
        max_timestep (int): Maximum environmental timestep.
        batch_size (int): Mini-batch size.
        learning_rate (float): Learning rate.
        encoder_factory (d3rlpy.models.encoders.EncoderFactory):
            Encoder factory.
        optim_factory (d3rlpy.optimizers.OptimizerFactory):
            Optimizer factory.
        num_heads (int): Number of attention heads.
        num_layers (int): Number of attention blocks.
        attn_dropout (float): Dropout probability for attentions.
        resid_dropout (float): Dropout probability for residual connection.
        embed_dropout (float): Dropout probability for embeddings.
        activation_type (str): Type of activation function.
        position_encoding_type (d3rlpy.PositionEncodingType):
            Type of positional encoding (``SIMPLE`` or ``GLOBAL``).
        compile_graph (bool): Flag to enable JIT compilation and CUDAGraph.
    """

    batch_size: int = 64
    learning_rate: float = 1e-4
    encoder_factory: EncoderFactory = make_encoder_field()
    optim_factory: OptimizerFactory = make_optimizer_field()
    num_heads: int = 1
    num_layers: int = 3
    attn_dropout: float = 0.1
    resid_dropout: float = 0.1
    embed_dropout: float = 0.1
    activation_type: str = "relu"
    position_encoding_type: PositionEncodingType = PositionEncodingType.SIMPLE
    compile_graph: bool = False

    def create(
        self, device: DeviceArg = False, enable_ddp: bool = False
    ) -> "DecisionTransformer":
        return DecisionTransformer(self, device, enable_ddp)

    @staticmethod
    def get_type() -> str:
        return "decision_transformer"


class DecisionTransformer(
    TransformerAlgoBase[DecisionTransformerImpl, DecisionTransformerConfig]
):
    def inner_create_impl(
        self, observation_shape: Shape, action_size: int
    ) -> None:
        transformer = create_continuous_decision_transformer(
            observation_shape=observation_shape,
            action_size=action_size,
            encoder_factory=self._config.encoder_factory,
            num_heads=self._config.num_heads,
            max_timestep=self._config.max_timestep,
            num_layers=self._config.num_layers,
            context_size=self._config.context_size,
            attn_dropout=self._config.attn_dropout,
            resid_dropout=self._config.resid_dropout,
            embed_dropout=self._config.embed_dropout,
            activation_type=self._config.activation_type,
            position_encoding_type=self._config.position_encoding_type,
            device=self._device,
            enable_ddp=self._enable_ddp,
        )
        optim = self._config.optim_factory.create(
            transformer.named_modules(),
            lr=self._config.learning_rate,
            compiled=self.compiled,
        )

        modules = DecisionTransformerModules(
            transformer=transformer,
            optim=optim,
        )

        self._impl = DecisionTransformerImpl(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            device=self._device,
            compiled=self.compiled,
        )

    def get_action_type(self) -> ActionSpace:
        return ActionSpace.CONTINUOUS


@dataclasses.dataclass()
class DiscreteDecisionTransformerConfig(TransformerConfig):
    """Config of Decision Transformer for discrte action-space.

    Decision Transformer solves decision-making problems as a sequence modeling
    problem.

    References:
        * `Chen at el., Decision Transformer: Reinforcement Learning via
          Sequence Modeling. <https://arxiv.org/abs/2106.01345>`_

    Args:
        observation_scaler (d3rlpy.preprocessing.ObservationScaler):
            Observation preprocessor.
        reward_scaler (d3rlpy.preprocessing.RewardScaler): Reward preprocessor.
        context_size (int): Prior sequence length.
        max_timestep (int): Maximum environmental timestep.
        batch_size (int): Mini-batch size.
        learning_rate (float): Learning rate.
        encoder_factory (d3rlpy.models.encoders.EncoderFactory):
            Encoder factory.
        optim_factory (d3rlpy.optimizers.OptimizerFactory):
            Optimizer factory.
        num_heads (int): Number of attention heads.
        num_layers (int): Number of attention blocks.
        attn_dropout (float): Dropout probability for attentions.
        resid_dropout (float): Dropout probability for residual connection.
        embed_dropout (float): Dropout probability for embeddings.
        activation_type (str): Type of activation function.
        embed_activation_type (str): Type of activation function applied to
            embeddings.
        position_encoding_type (d3rlpy.PositionEncodingType):
            Type of positional encoding (``SIMPLE`` or ``GLOBAL``).
        warmup_tokens (int): Number of tokens to warmup learning rate scheduler.
        final_tokens (int): Final number of tokens for learning rate scheduler.
        compile_graph (bool): Flag to enable JIT compilation and CUDAGraph.
    """

    batch_size: int = 128
    learning_rate: float = 6e-4
    encoder_factory: EncoderFactory = make_encoder_field()
    optim_factory: OptimizerFactory = make_optimizer_field()
    num_heads: int = 8
    num_layers: int = 6
    attn_dropout: float = 0.1
    resid_dropout: float = 0.1
    embed_dropout: float = 0.1
    activation_type: str = "gelu"
    embed_activation_type: str = "tanh"
    position_encoding_type: PositionEncodingType = PositionEncodingType.GLOBAL
    warmup_tokens: int = 10240
    final_tokens: int = 30000000
    compile_graph: bool = False

    def create(
        self, device: DeviceArg = False, enable_ddp: bool = False
    ) -> "DiscreteDecisionTransformer":
        return DiscreteDecisionTransformer(self, device, enable_ddp)

    @staticmethod
    def get_type() -> str:
        return "discrete_decision_transformer"


class DiscreteDecisionTransformer(
    TransformerAlgoBase[
        DiscreteDecisionTransformerImpl, DiscreteDecisionTransformerConfig
    ]
):
    def inner_create_impl(
        self, observation_shape: Shape, action_size: int
    ) -> None:
        transformer = create_discrete_decision_transformer(
            observation_shape=observation_shape,
            action_size=action_size,
            encoder_factory=self._config.encoder_factory,
            num_heads=self._config.num_heads,
            max_timestep=self._config.max_timestep,
            num_layers=self._config.num_layers,
            context_size=self._config.context_size,
            attn_dropout=self._config.attn_dropout,
            resid_dropout=self._config.resid_dropout,
            embed_dropout=self._config.embed_dropout,
            activation_type=self._config.activation_type,
            embed_activation_type=self._config.embed_activation_type,
            position_encoding_type=self._config.position_encoding_type,
            device=self._device,
            enable_ddp=self._enable_ddp,
        )
        optim = self._config.optim_factory.create(
            transformer.named_modules(),
            lr=self._config.learning_rate,
            compiled=self.compiled,
        )

        modules = DiscreteDecisionTransformerModules(
            transformer=transformer,
            optim=optim,
        )

        self._impl = DiscreteDecisionTransformerImpl(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            warmup_tokens=self._config.warmup_tokens,
            final_tokens=self._config.final_tokens,
            initial_learning_rate=self._config.learning_rate,
            compiled=self.compiled,
            device=self._device,
        )

    def get_action_type(self) -> ActionSpace:
        return ActionSpace.DISCRETE


register_learnable(DecisionTransformerConfig)
register_learnable(DiscreteDecisionTransformerConfig)


#######################################################################

from .action_samplers import (
    QActionSampler,
    IdentityQActionSampler,
    QActionScorer,
    LogitsQActionScorer,
)

from .torch.decision_transformer_impl import (
    QDiscreteDecisionTransformerImpl,
    QDiscreteDecisionTransformerModules,
    AQDiscreteDecisionTransformerImpl,
    AQDiscreteDecisionTransformerModules,
    AQDecisionTransformerImpl,
    AQDecisionTransformerModules,
    DecoupledDecisionTransformerImpl,
    DecoupledDecisionTransformerModules,
    DecoupledDiscreteDecisionTransformerImpl,
    DecoupledDiscreteDecisionTransformerModules,
)

from ...models.builders import (
    create_q_discrete_decision_transformer,
    create_aq_discrete_decision_transformer,
    create_pc_discrete_decision_transformer,
    create_aq_continuous_decision_transformer,
    create_pc_continuous_decision_transformer,
)


# 不考虑分布外泛化问题的版本，执行动态规划
@dataclasses.dataclass()
class QDiscreteDecisionTransformerConfig(TransformerConfig):

    batch_size: int = 128
    learning_rate: float = 6e-4
    encoder_factory: EncoderFactory = make_encoder_field()
    optim_factory: OptimizerFactory = make_optimizer_field()
    num_heads: int = 8
    num_layers: int = 6
    attn_dropout: float = 0.1
    resid_dropout: float = 0.1
    embed_dropout: float = 0.1
    activation_type: str = "gelu"
    embed_activation_type: str = "tanh"
    q_activation_type: str = "relu"
    position_encoding_type: PositionEncodingType = PositionEncodingType.GLOBAL
    warmup_tokens: int = 10240
    final_tokens: int = 30000000
    compile_graph: bool = False

    def create(
        self, device: DeviceArg = False, enable_ddp: bool = False
    ) -> "QDiscreteDecisionTransformer":
        return QDiscreteDecisionTransformer(self, device, enable_ddp)

    @staticmethod
    def get_type() -> str:
        return "q_discrete_decision_transformer"


class QDiscreteDecisionTransformer(
    TransformerAlgoBase[
        QDiscreteDecisionTransformerImpl, QDiscreteDecisionTransformerConfig
    ]
):
    def inner_create_impl(
        self, observation_shape: Shape, action_size: int
    ) -> None:
        transformer = create_q_discrete_decision_transformer(
            observation_shape=observation_shape,
            action_size=action_size,
            encoder_factory=self._config.encoder_factory,
            num_heads=self._config.num_heads,
            max_timestep=self._config.max_timestep,
            num_layers=self._config.num_layers,
            context_size=self._config.context_size,
            attn_dropout=self._config.attn_dropout,
            resid_dropout=self._config.resid_dropout,
            embed_dropout=self._config.embed_dropout,
            activation_type=self._config.activation_type,
            embed_activation_type=self._config.embed_activation_type,
            q_activation_type=self._config.q_activation_type,
            position_encoding_type=self._config.position_encoding_type,
            device=self._device,
            enable_ddp=self._enable_ddp,
        )
        optim = self._config.optim_factory.create(
            transformer.named_modules(),
            lr=self._config.learning_rate,
            compiled=self.compiled,
        )

        modules = QDiscreteDecisionTransformerModules(
            transformer=transformer,
            optim=optim,
        )

        self._impl = QDiscreteDecisionTransformerImpl(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            warmup_tokens=self._config.warmup_tokens,
            final_tokens=self._config.final_tokens,
            initial_learning_rate=self._config.learning_rate,
            compiled=self.compiled,
            device=self._device,
        )

    def get_action_type(self) -> ActionSpace:
        return ActionSpace.DISCRETE


@dataclasses.dataclass()
class AQDiscreteDecisionTransformerConfig(TransformerConfig):

    batch_size: int = 128
    learning_rate: float = 6e-4
    encoder_factory: EncoderFactory = make_encoder_field()
    optim_factory: OptimizerFactory = make_optimizer_field()
    num_heads: int = 8
    num_layers: int = 6
    attn_dropout: float = 0.1
    resid_dropout: float = 0.1
    embed_dropout: float = 0.1
    activation_type: str = "gelu"
    embed_activation_type: str = "tanh"
    q_activation_type: str = "relu"
    position_encoding_type: PositionEncodingType = PositionEncodingType.GLOBAL
    warmup_tokens: int = 10240
    final_tokens: int = 30000000
    compile_graph: bool = False
    q_layers: int = 1
    q_loss_ratio: float = 0.5
    q_action_scorer: QActionScorer = LogitsQActionScorer()
    clip_min: float = 0.5
    clip_max: float = 1.5

    def create(
        self, device: DeviceArg = False, enable_ddp: bool = False
    ) -> "AQDiscreteDecisionTransformer":
        return AQDiscreteDecisionTransformer(self, device, enable_ddp)

    @staticmethod
    def get_type() -> str:
        return "aq_discrete_decision_transformer"


class AQDiscreteDecisionTransformer(
    TransformerAlgoBase[
        AQDiscreteDecisionTransformerImpl, AQDiscreteDecisionTransformerConfig
    ]
):
    def inner_create_impl(
        self, observation_shape: Shape, action_size: int
    ) -> None:
        transformer = create_aq_discrete_decision_transformer(
            observation_shape=observation_shape,
            action_size=action_size,
            encoder_factory=self._config.encoder_factory,
            num_heads=self._config.num_heads,
            max_timestep=self._config.max_timestep,
            num_layers=self._config.num_layers,
            context_size=self._config.context_size,
            attn_dropout=self._config.attn_dropout,
            resid_dropout=self._config.resid_dropout,
            embed_dropout=self._config.embed_dropout,
            activation_type=self._config.activation_type,
            embed_activation_type=self._config.embed_activation_type,
            q_activation_type=self._config.q_activation_type,
            position_encoding_type=self._config.position_encoding_type,
            device=self._device,
            enable_ddp=self._enable_ddp,
            q_layers=self._config.q_layers,
        )

        optim = self._config.optim_factory.create(
            transformer.named_modules(),
            lr=self._config.learning_rate,
            compiled=self.compiled,
        )

        modules = AQDiscreteDecisionTransformerModules(
            transformer=transformer,
            optim=optim,
        )

        self._impl = AQDiscreteDecisionTransformerImpl(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            warmup_tokens=self._config.warmup_tokens,
            final_tokens=self._config.final_tokens,
            initial_learning_rate=self._config.learning_rate,
            compiled=self.compiled,
            device=self._device,
            q_loss_ratio=self._config.q_loss_ratio,
            q_action_scorer=self._config.q_action_scorer,
            clip_min=self._config.clip_min,
            clip_max=self._config.clip_max,
        )

    def get_action_type(self) -> ActionSpace:
        return ActionSpace.DISCRETE


@dataclasses.dataclass()
class AQDecisionTransformerConfig(TransformerConfig):

    batch_size: int = 64
    learning_rate: float = 1e-4
    encoder_factory: EncoderFactory = make_encoder_field()
    optim_factory: OptimizerFactory = make_optimizer_field()
    num_heads: int = 1
    num_layers: int = 3
    attn_dropout: float = 0.1
    resid_dropout: float = 0.1
    embed_dropout: float = 0.1
    activation_type: str = "relu"
    q_activation_type: str = "relu"
    position_encoding_type: PositionEncodingType = PositionEncodingType.SIMPLE
    compile_graph: bool = False
    q_layers: int = 1
    q_loss_ratio: float = 0.5
    q_action_sampler: QActionSampler = IdentityQActionSampler()

    def create(
        self, device: DeviceArg = False, enable_ddp: bool = False
    ) -> "AQDecisionTransformer":
        return AQDecisionTransformer(self, device, enable_ddp)

    @staticmethod
    def get_type() -> str:
        return "aq_decision_transformer"


class AQDecisionTransformer(
    TransformerAlgoBase[AQDecisionTransformerImpl, AQDecisionTransformerConfig]
):
    def inner_create_impl(
        self, observation_shape: Shape, action_size: int
    ) -> None:
        transformer = create_aq_continuous_decision_transformer(
            observation_shape=observation_shape,
            action_size=action_size,
            encoder_factory=self._config.encoder_factory,
            num_heads=self._config.num_heads,
            max_timestep=self._config.max_timestep,
            num_layers=self._config.num_layers,
            context_size=self._config.context_size,
            attn_dropout=self._config.attn_dropout,
            resid_dropout=self._config.resid_dropout,
            embed_dropout=self._config.embed_dropout,
            activation_type=self._config.activation_type,
            q_activation_type=self._config.q_activation_type,
            position_encoding_type=self._config.position_encoding_type,
            device=self._device,
            enable_ddp=self._enable_ddp,
            q_layers=self._config.q_layers,
        )
        optim = self._config.optim_factory.create(
            transformer.named_modules(),
            lr=self._config.learning_rate,
            compiled=self.compiled,
        )
        modules = AQDecisionTransformerModules(
            transformer=transformer,
            optim=optim,
        )

        self._impl = AQDecisionTransformerImpl(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            compiled=self.compiled,
            device=self._device,
            q_loss_ratio=self._config.q_loss_ratio,
            q_action_sampler=self._config.q_action_sampler,
        )

    def get_action_type(self) -> ActionSpace:
        return ActionSpace.CONTINUOUS


@dataclasses.dataclass()
class DecoupledDecisionTransformerConfig(TransformerConfig):

    batch_size: int = 64
    learning_rate: float = 1e-4
    encoder_factory: EncoderFactory = make_encoder_field()
    optim_factory: OptimizerFactory = make_optimizer_field()
    num_heads: int = 1
    num_layers: int = 3
    attn_dropout: float = 0.1
    resid_dropout: float = 0.1
    embed_dropout: float = 0.1
    activation_type: str = "relu"
    position_encoding_type: PositionEncodingType = PositionEncodingType.SIMPLE
    compile_graph: bool = False

    def create(
        self, device: DeviceArg = False, enable_ddp: bool = False
    ) -> "DecoupledDecisionTransformer":
        return DecoupledDecisionTransformer(self, device, enable_ddp)

    @staticmethod
    def get_type() -> str:
        return "pc_decision_transformer"


class DecoupledDecisionTransformer(
    TransformerAlgoBase[DecoupledDecisionTransformerImpl, DecoupledDecisionTransformerConfig]
):
    def inner_create_impl(
        self, observation_shape: Shape, action_size: int
    ) -> None:
        transformer = create_pc_continuous_decision_transformer(
            observation_shape=observation_shape,
            action_size=action_size,
            encoder_factory=self._config.encoder_factory,
            num_heads=self._config.num_heads,
            max_timestep=self._config.max_timestep,
            num_layers=self._config.num_layers,
            context_size=self._config.context_size,
            attn_dropout=self._config.attn_dropout,
            resid_dropout=self._config.resid_dropout,
            embed_dropout=self._config.embed_dropout,
            activation_type=self._config.activation_type,
            position_encoding_type=self._config.position_encoding_type,
            device=self._device,
            enable_ddp=self._enable_ddp,
        )
        optim = self._config.optim_factory.create(
            transformer.named_modules(),
            lr=self._config.learning_rate,
            compiled=self.compiled,
        )

        modules = DecoupledDecisionTransformerModules(
            transformer=transformer,
            optim=optim,
        )

        self._impl = DecoupledDecisionTransformerImpl(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            device=self._device,
            compiled=self.compiled,
        )

    def get_action_type(self) -> ActionSpace:
        return ActionSpace.CONTINUOUS


@dataclasses.dataclass()
class DecoupledDiscreteDecisionTransformerConfig(TransformerConfig):

    batch_size: int = 128
    learning_rate: float = 6e-4
    encoder_factory: EncoderFactory = make_encoder_field()
    optim_factory: OptimizerFactory = make_optimizer_field()
    num_heads: int = 8
    num_layers: int = 6
    attn_dropout: float = 0.1
    resid_dropout: float = 0.1
    embed_dropout: float = 0.1
    activation_type: str = "gelu"
    embed_activation_type: str = "tanh"
    position_encoding_type: PositionEncodingType = PositionEncodingType.GLOBAL
    warmup_tokens: int = 10240
    final_tokens: int = 30000000
    compile_graph: bool = False

    def create(
        self, device: DeviceArg = False, enable_ddp: bool = False
    ) -> "DecoupledDiscreteDecisionTransformer":
        return DecoupledDiscreteDecisionTransformer(self, device, enable_ddp)

    @staticmethod
    def get_type() -> str:
        return "pc_discrete_decision_transformer"


class DecoupledDiscreteDecisionTransformer(
    TransformerAlgoBase[
        DecoupledDiscreteDecisionTransformerImpl, DecoupledDiscreteDecisionTransformerConfig
    ]
):
    def inner_create_impl(
        self, observation_shape: Shape, action_size: int
    ) -> None:
        transformer = create_pc_discrete_decision_transformer(
            observation_shape=observation_shape,
            action_size=action_size,
            encoder_factory=self._config.encoder_factory,
            num_heads=self._config.num_heads,
            max_timestep=self._config.max_timestep,
            num_layers=self._config.num_layers,
            context_size=self._config.context_size,
            attn_dropout=self._config.attn_dropout,
            resid_dropout=self._config.resid_dropout,
            embed_dropout=self._config.embed_dropout,
            activation_type=self._config.activation_type,
            embed_activation_type=self._config.embed_activation_type,
            position_encoding_type=self._config.position_encoding_type,
            device=self._device,
            enable_ddp=self._enable_ddp,
        )
        optim = self._config.optim_factory.create(
            transformer.named_modules(),
            lr=self._config.learning_rate,
            compiled=self.compiled,
        )

        modules = DecoupledDiscreteDecisionTransformerModules(
            transformer=transformer,
            optim=optim,
        )

        self._impl = DecoupledDiscreteDecisionTransformerImpl(
            observation_shape=observation_shape,
            action_size=action_size,
            modules=modules,
            warmup_tokens=self._config.warmup_tokens,
            final_tokens=self._config.final_tokens,
            initial_learning_rate=self._config.learning_rate,
            compiled=self.compiled,
            device=self._device,
        )

    def get_action_type(self) -> ActionSpace:
        return ActionSpace.DISCRETE


register_learnable(QDiscreteDecisionTransformerConfig)
register_learnable(AQDiscreteDecisionTransformerConfig)
register_learnable(AQDecisionTransformerConfig)
register_learnable(DecoupledDiscreteDecisionTransformerConfig)
register_learnable(DecoupledDecisionTransformerConfig)

__all__.extend([
    QDiscreteDecisionTransformer.__name__,
    QDiscreteDecisionTransformerConfig.__name__,
    AQDiscreteDecisionTransformer.__name__,
    AQDiscreteDecisionTransformerConfig.__name__,
    AQDecisionTransformer.__name__,
    AQDecisionTransformerConfig.__name__,
    DecoupledDecisionTransformer.__name__,
    DecoupledDecisionTransformerConfig.__name__,
    DecoupledDiscreteDecisionTransformer.__name__,
    DecoupledDiscreteDecisionTransformerConfig.__name__,
])
