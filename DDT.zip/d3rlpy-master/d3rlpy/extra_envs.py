#######################################################################
from typing import Optional

import numpy as np
import gym
from gym import spaces

from .dataset import MDPDataset
from .constants import ActionSpace


class BernoulliBanditEnv(gym.Env):
    def __init__(
        self,
        p: float,
        seed: Optional[int] = None,
    ):
        self._p = p
        self._obs = np.zeros(1, dtype=np.float32)
        self.observation_space = spaces.Discrete(1)
        self.action_space = spaces.Discrete(2)
        super().reset(seed=seed)
    
    def reset(self):
        # bandit has only one state
        return self._obs, {}
    
    def step(self, action):
        rv = np.random.rand()
        reward = float(
            rv < self._p if action == 0 
            else rv >= self._p
        )
        return self._obs, reward, True, False, {}

    # action=0: Bernoulli(p)
    # action=1: Bernoulli(1-p)
    # policy:   Bernoulli(p)
    def balance_policy(self):
        return np.random.rand() < self._p
    
    def get_dataset(self, n_episode: int):
        
        obs, act, rew, term, tout = list(), list(), list(), list(), list()
        for _ in range(n_episode):
            s = self.reset()[0]
            a = self.balance_policy()
            s, r, te, tr, _ = self.step(a)
            obs.append(s)
            act.append(a)
            rew.append(r)
            term.append(te)
            tout.append(tr)
        return MDPDataset(
            observations = np.array(obs, dtype=np.float32),
            actions = np.array(act, dtype=np.int32),
            rewards = np.array(rew, dtype=np.float32),
            terminals = np.array(term, dtype=np.bool_),
            timeouts = np.array(tout, dtype=np.bool_),
            action_space = ActionSpace.DISCRETE
        )


class WrappedFrozenLakeEnv(gym.Env):
    
    def __init__(self, act_succ_rate=1/3, seed=None):
        
        # adapt to v0 setting
        self._env = gym.make(
            "FrozenLake-v1",
            map_name="4x4",
            is_slippery=True,
            act_succ_rate=act_succ_rate,
            max_episode_steps=None
        )
        self.observation_space = spaces.Box(low=0.0, high=15.0, shape=(1,))
        self.action_space = self._env.action_space

        if seed is not None:
            self.reset(seed=seed)

    @staticmethod
    def wrap_obs(obs: np.float32):
        return np.array([obs], dtype=np.float32)

    def reset(self, seed=None):
        obs, info = self._env.reset(seed=seed)
        return self.wrap_obs(obs), info
    
    def step(self, action: int):
        obs, reward, terminated, truncated, info = self._env.step(action)
        return self.wrap_obs(obs), reward, terminated, truncated, info